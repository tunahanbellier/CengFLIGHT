#ifndef HASH_TABLE_HPP
#define HASH_TABLE_HPP

//=======================//
// Implemented Functions //
//=======================//
template<int MAX_SIZE>
int HashTable<MAX_SIZE>::PRIMES[3] = {102523, 100907, 104659};

template<int MAX_SIZE>
void HashTable<MAX_SIZE>::PrintLine(int tableIndex) const
{
    const HashData& data = table[tableIndex];

    // Using printf here it is easier to format
    if(data.sentinel == SENTINEL_MARK)
    {
        printf("[%03d]         : SENTINEL\n", tableIndex);
    }
    else if(data.sentinel == EMPTY_MARK)
    {
        printf("[%03d]         : EMPTY\n", tableIndex);
    }
    else
    {
        printf("[%03d] - [%03d] : ", tableIndex, data.lruCounter);
        printf("(%-5s) ", data.isCostWeighted ? "True" : "False");
        size_t sz = data.intArray.size();
        for(size_t i = 0; i < sz; i++)
        {
            if(i % 2 == 0)
                printf("[%03d]", data.intArray[i]);
            else
                printf("/%03d/", data.intArray[i]);

            if(i != sz - 1)
                printf("-->");
        }
        printf("\n");
    }
}

template<int MAX_SIZE>
void HashTable<MAX_SIZE>::PrintTable() const
{
    printf("____________________\n");
    printf("Elements %d\n", elementCount);
    printf("[IDX] - [LRU] | DATA\n");
    printf("____________________\n");
    for(int i = 0; i < MAX_SIZE; i++)
    {
        PrintLine(i);
    }
}

//=======================//
//          TODO         //
//=======================//
template<int MAX_SIZE>
int HashTable<MAX_SIZE>::Hash(int startInt, int endInt, bool isCostWeighted)
{
    int hash = (PRIMES[0]*startInt) + (PRIMES[1]*endInt) + (PRIMES[2]*isCostWeighted);
    if (hash < 0) hash = -hash ; 
    return hash % MAX_SIZE;
    /* TODO */
    
}

template<int MAX_SIZE>
HashTable<MAX_SIZE>::HashTable()
{
    elementCount = 0;
    for ( int i = 0 ; i< MAX_SIZE ; i++){
        table[i].lruCounter = 0;
        table[i].sentinel = EMPTY_MARK;
        
    }
    /* TODO */
}

template<int MAX_SIZE>
int HashTable<MAX_SIZE>::Insert(const std::vector<int>& intArray, bool isCostWeighted)
{
    if (intArray.empty()) {
        throw InvalidTableArgException();
    }

   
    int startInt = intArray.front();
    int endInt = intArray.back();

    
    int hash = Hash(startInt, endInt, isCostWeighted);

    
    int probe = 1;
    int originalHash = hash;

    
    while (table[hash].sentinel != EMPTY_MARK && table[hash].sentinel != SENTINEL_MARK) {
        // Check if the same key is found, if yes, increment LRU and return
        if (table[hash].sentinel == OCCUPIED_MARK &&
            table[hash].intArray == intArray &&
            table[hash].isCostWeighted == isCostWeighted) {
            table[hash].lruCounter++;
            return table[hash].lruCounter;
        }

        
        hash = (originalHash + probe * probe) % MAX_SIZE;
        probe++;
    }

    
    if (elementCount >= MAX_SIZE*0.5) {
        throw TableCapFullException(elementCount);
    }

    
    table[hash].sentinel = OCCUPIED_MARK;
    table[hash].intArray = intArray;
    table[hash].isCostWeighted = isCostWeighted;
    table[hash].lruCounter = 1;
    elementCount++;

    return table[hash].lruCounter;

}

template<int MAX_SIZE>
bool HashTable<MAX_SIZE>::Find(std::vector<int>& intArray,
                               int startInt, int endInt, bool isCostWeighted,
                               bool incLRU)
{
    /* TODO */
    int hash = Hash(startInt,endInt,isCostWeighted);
    for (int i = 0; i<MAX_SIZE; i++ ){
        
        if (table[i].sentinel == OCCUPIED_MARK){
            int hashi = Hash(table[i].intArray[0],table[i].intArray[table[i].intArray.size()-1],table[i].isCostWeighted);
            if (hashi == hash && table[i].intArray[0]==startInt){
                intArray = table[i].intArray;
                if (incLRU){
                    table[i].lruCounter++;
                }
                
                return true;
            }
        }
    }
    return false;

}

template<int MAX_SIZE>
void HashTable<MAX_SIZE>::InvalidateTable()
{
    for (int i = 0; i < MAX_SIZE; ++i) {
        
        table[i].sentinel = EMPTY_MARK;
        table[i].lruCounter = 0;
        table[i].intArray.clear();  
        
    }

    
    elementCount = 0;
    /* TODO */
}

template<int MAX_SIZE>
void HashTable<MAX_SIZE>::GetMostInserted(std::vector<int>& intArray) const
{
    int maxLRU = 0;
    int maxLRUIndex = -1;

    
    for (int i = 0; i < MAX_SIZE; ++i) {
        
        if (table[i].sentinel == OCCUPIED_MARK && table[i].lruCounter > maxLRU) {
            maxLRU = table[i].lruCounter;
            maxLRUIndex = i;
        }
    }

    
    if (maxLRUIndex != -1) {
        intArray = table[maxLRUIndex].intArray;
    }
    /* TODO */
}

template<int MAX_SIZE>
void HashTable<MAX_SIZE>::Remove(std::vector<int>& intArray,
                                 int startInt, int endInt, bool isCostWeighted)
{
    int hash = Hash(startInt,endInt,isCostWeighted);
    for (int i = 0 ; i<MAX_SIZE; i++){
        if (table[i].sentinel == OCCUPIED_MARK ){
            int hashi = Hash(table[i].intArray[0],table[i].intArray[table[i].intArray.size()-1],table[i].isCostWeighted);
                if (hashi == hash && table[i].intArray[0] == startInt){
                    intArray = table[i].intArray;
                    table[i].sentinel = SENTINEL_MARK;
                    elementCount--;
                    break;
                }
            
        }
    }
    /* TODO */
}

template<int MAX_SIZE>
void HashTable<MAX_SIZE>::RemoveLRU(int lruElementCount)
{
    /* TODO */
    int count = lruElementCount;
    int mini;
    int indexmin;
    int indexforite;
    while(count > 0){
        //set min first element
        for ( int i = 0; i<MAX_SIZE;i++){
            if (table[i].sentinel == OCCUPIED_MARK){
                mini = table[i].lruCounter;
                indexmin=i;
                indexforite = i;
                break;
            }
        }
        //set min for other elements
        for( int j = indexforite;j<MAX_SIZE;j++ ){
            if(table[j].sentinel == OCCUPIED_MARK){
                if(table[j].lruCounter < mini){
                    table[j].lruCounter = mini;
                    indexmin=j;
                }
            }
        }
        table[indexmin].sentinel = SENTINEL_MARK;
        elementCount--;
        count--;
    }
}

template<int MAX_SIZE>
void HashTable<MAX_SIZE>::PrintSortedLRUEntries() const
{
    
    MaxPairHeap<int, int> lruHeap;

    
    for (int i = 0; i < MAX_SIZE; ++i) {
        if (table[i].sentinel == OCCUPIED_MARK && table[i].lruCounter > 0) {
            lruHeap.push({table[i].lruCounter, i});
        }
    }

    
    while (!lruHeap.empty()) {
        int index = lruHeap.top().value;
        PrintLine(index);
        lruHeap.pop();
    }
    /* TODO */
}

#endif // HASH_TABLE_HPP